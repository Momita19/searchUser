'use client';

import React, { useState } from 'react';
import data from '../api/data.json'

const SearchUser = ({ usersData, setUser, onAddUser }) => {
  const [query, setQuery] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);

  const filterusers =
  query === ""
      ? usersData
      : usersData.filter((item) => (
          item.toLowerCase()
              .replace(/\+/g, "")
              .includes(query.toLowerCase().replace(/\s+/g, ""))
      ));

  const handleRemoveUser = (removedUser) => {
    const updatedUsers = filteredUsers.filter((user) => user !== removedUser);
    setFilteredUsers(updatedUsers);
    setUser(updatedUsers.map((user) => data.user.name)); // Update the user state with only names
  };
  const handleSelectChange = (event) => {
    const selectedValues = Array.from(event.target.selectedOptions, option => option.value);
    setSelectedOptions(selectedValues);
  };

  return (
    <div className="relative mt-2 rounded-md shadow-sm">
      <input
        type="text"
        name="search"
        id="search"
        className="border p-2 rounded w-full mb-4"
        placeholder="Search user..."
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          filterUsers(e.target.value);
        }}
      />
      <div className="absolute z-10 mt-1 w-full rounded-md bg-white shadow-lg">
        {filteredUsers.map((user) => (
          <div key={user.name} className="flex items-center justify-between p-2 border-b">
            <span>{user.name}</span>
            <button type="button" onClick={() => handleRemoveUser(user)}>
              <svg
                className="w-4 h-4 cursor-pointer"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M6 18L18 6M6 6l12 12"
                ></path>
              </svg>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SearchUser;
