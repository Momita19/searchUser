// Import statements
'use client';
import React, { useState, useEffect, useRef } from 'react';
import items from '../api/data.json';

// SearchBar component
const SearchBar = () => {
  const [input, setInput] = useState("");
  const [chips, setChips] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [highlightedChip, setHighlightedChip] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    setFilteredItems(
      items.filter(
        (item) =>
          !chips.includes(item.name) &&
          item.name.toLowerCase().includes(input.toLowerCase())
      )
    );
  }, [input, chips]);

  const handleInputChange = (event) => {
    setInput(event.target.value);
  };

  const handleInputFocus = () => {
    setShowSuggestions(true);
  };

  const handleInputBlur = () => {
    setTimeout(() => {
      setShowSuggestions(false);
    }, 200);
  };

  const handleItemSelect = (selectedItem) => {
    setChips([...chips, selectedItem]);
    setInput("");
    setShowSuggestions(false);
  };

  const handleChipRemove = (removedChip) => {
    setChips(chips.filter((chip) => chip !== removedChip));
  };

  const handleInputKeyDown = (event) => {
    if (event.key === "Backspace" && input === "" && chips.length > 0) {
      const lastChip = chips[chips.length - 1];
      setHighlightedChip(lastChip);
      event.preventDefault();
    }
    if (event.key === "Backspace" && highlightedChip) {
      handleChipRemove(highlightedChip);
      setHighlightedChip(null);
    }
  };

  const handleInputClick = () => {
    if (input.length >= 1) {
      setShowSuggestions(true);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'column', width: '100%', borderBottom: '4px solid #007bff' }}>
        <div className="display-flex" style={{ flexWrap: 'wrap' }}>
          {chips.map((chip, index) => (
            <div key={index} className={`chip ${highlightedChip === chip ? 'highlighted' : ''}`}>
              {chip}{" "}
              <span
                onClick={() => handleChipRemove(chip)}
                className="ml-0.5" style={{ cursor: 'pointer' }}
              >
                X
              </span>
            </div>
          ))}

          <div>
            <input
              type="text"
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleInputKeyDown}
              onClick={handleInputClick}
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              placeholder="Search user name..."
            />

            {showSuggestions && (
              <div className="suggestions-dropdown">
                {filteredItems.map((item, index) => (
                  <div
                    key={index}
                    onMouseDown={() => handleItemSelect(item.name)}
                    className="suggestion-item"
                  >
                    {item.name}
                    {/* <div>
                    {item.gmail}
                    </div> */}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
